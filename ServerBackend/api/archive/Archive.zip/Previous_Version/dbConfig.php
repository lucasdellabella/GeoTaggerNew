<?php

define("DB_Server", "localhost");
define("DB_User", "root");
define("DB_Password", "123root");
define("DB_Name", "geotagger");

?>