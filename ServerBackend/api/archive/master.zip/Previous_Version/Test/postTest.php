<?php
if (!empty($_POST["mail"])) {
    echo "Yes, mail is set";    
}else{  
    echo "N0, mail is not set";
}
?>